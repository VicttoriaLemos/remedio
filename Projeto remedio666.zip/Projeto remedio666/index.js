const mysql = require('mysql2');
const express = require('express');
const bodyParser = require('body-parser');


const app = express();


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static('public'));


const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'medicamentos'
});


connection.connect(function (err) {
    if (err) {
        console.error('Erro: ', err);
        return;
    }
    console.log("Conexão estabelecida com sucesso!");
});

/*Inicio */
/*rota tela inicial*/
app.get("/", function (req, res) {
    res.send(`
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lembrete de Medicamentos</title>
    <link rel="icon" type="image/x-icon" href="icon.png">
    <link rel="stylesheet" type="text/css" href="/estilo.css">
    <script src="index.js" defer></script>
</head>
<body class="telaInicio">
    <article class="imagem">
        <h1>Lembretes para medicamentos e para renovações de receitas médicas.</h1>  
            <a href="http://localhost:8081/login"> Entrar</a>
            <a href="http://localhost:8081/criarConta">Criar Conta</a>
    </article>
    <footer></footer>

</body>

</html>
    
    `);
});
/*Fim inicio */

/*Inicio crud cadastro de medicamentos*/


app.get("/medicamentos", function (req, res) {
    res.sendFile(__dirname + "/medicamentos.html")
});

// Endpoint para adicionar medicamentos
app.post('/adicionarmedicamentos', (req, res) => {
    const { nomeMed, horaTomou, horaTomara, fazUso_qtd } = req.body;

    const values = [nomeMed, horaTomou, horaTomara, fazUso_qtd];
    const insert = "INSERT INTO remedio(nomeMed, horaTomou, horaTomara, fazUso_qtd) VALUES (?,?,?,?)";

    connection.query(insert, values, function (err, result) {
        if (!err) {
            console.log("Dados inseridos com sucesso!");
            res.send("Dados inseridos!");
        } else {
            console.log("Não foi possível inserir os dados ", err);
            res.send("Erro!");
        }
    });
});

// Rota para listar os dados do BD
app.get("/listarmedicamentos", function (req, res) {
    const selectAll = "SELECT * FROM remedio";

    connection.query(selectAll, function (err, rows) {
        if (!err) {
            res.send(`
                <html lang="pt-br">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Lista de Medicamentos</title>
                    <link rel="icon" type="image/x-icon" href="icon.png">
                    <link rel="stylesheet" type="text/css" href="/estilo.css">
                    <script src="index.js" defer></script>
                </head>
                <body>
                    <p>Lista de Medicamentos</p>
                    <div id="page-container">
                        <div id="content-wrap">
                            <table>
                                <tr>
                                    <th>Nome do Medicamento</th>
                                    <th>A cada ... hs</th>
                                    <th>Quantidade</th>
                                    <th>Editar</th>
                                    <th>Deletar</th>
                                </tr>
                                ${rows.map(row => `
                                <tr>
                                    <td>${row.nomeMed}</td>
                                    <td>${row.horaTomou}</td>
                                    <td>${row.horaTomara}</td>
                                    <td>${row.fazUso_qtd}</td>
                                    <td><a href="/atualizar-medicamento-form/${row.id_medicamento}">Editar</a></td>
                                    <td><a href="/deletar-medicamento/${row.id_medicamento}">Deletar</a></td>
                                </tr>
                                `).join('')}
                            </table>
                        </div>
                        <footer>
                            <a href="http://localhost:8081">Voltar</a>
                        </footer>
                    </div>
                </body>
                </html>
            `);
        } else {
            console.log("Erro ao carregar lista de medicamentos! ", err);
            res.send("Erro!");
        }
    });
});

// Rota para deletar os dados
app.get("/deletar-medicamento/:id_medicamento", function (req, res) {
    const id_medicamento = req.params.id_medicamento;

    const deletemedicamento = "DELETE FROM remedio WHERE id_medicamento = ?";

    connection.query(deletemedicamento, [id_medicamento], function (err, result) {
        if (!err) {
            console.log("Medicamento deletado!");
            res.redirect('/listarmedicamentos');
        } else {
            console.log("Erro ao deletar o medicamento!", err);
        }
    });
});

// Rota para atualizar os dados
app.get("/atualizar-medicamento-form/:id_medicamento", function (req, res) {
    const id_medicamento = req.params.id_medicamento;

    const selectremedio = "SELECT * FROM remedio WHERE id_medicamento=?";

    connection.query(selectremedio, [id_medicamento], function (err, result) {
        if (!err && result.length > 0) {
            const remedio = result[0];

            res.send(`
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Lembrete de Medicamentos</title>
               <link rel="icon" type="image/x-icon" href="icon.png">
                    <link rel="stylesheet" type="text/css" href="/estilo.css">
                    <script src="index.js" defer></script>
            </head>
            <body>
                <article>
                    <h1>Lembrete de Medicamentos</h1>
                    <form action="/atualizar-medicamento/${id_medicamento}" method="POST">
                        <div class="field">
                            <label for="nomeMed">Nome do Medicamento:</label>
                            <input type="text" id="nomeMed" name="nomeMed" value="${remedio.nomeMed}" required>
                        </div>
                        <div class="field">
                        <label for="horaTomou">Que horas você tomou sua última medicação?(HH:MM):</label>
                        <input type="time" id="horaTomou" name="horaTomou" value="${remedio.horaTomou}" required>
                    </div>
                        <div class="field">
                <label for="horatomara"></label>
               <select name="horaTomara" id="horaTomara" required>
                    <option value="">Selecione</option>
                    <option value="4" ${remedio.horaTomara == '4' ? 'selected' : ''}>4hs</option>
                    <option value="6" ${remedio.horaTomara == '6' ? 'selected' : ''}>6hs</option>
                    <option value="8" ${remedio.horaTomara == '8' ? 'selected' : ''}>8hs</option>
                    <option value="12" ${remedio.horaTomara == '12' ? 'selected' : ''}>12h</option>
                </select>
            </div>
                        <div class="field">
                            <label for="fazUso_qtd">Quantidade de Medicamentos:</label>
                            <input type="number" id="fazUso_qtd" name="fazUso_qtd" value="${remedio.fazUso_qtd}" required>
                        </div>
                        <input type="submit" value="Atualizar">
                    </form>
                </article>
                <footer></footer>
            </body>
            </html>
            `);
        } else {
            console.log("Erro ao obter dados do medicamento! ", err);
            res.send("Erro!");
        }
    });
});

app.post('/atualizar-medicamento/:id_medicamento', (req, res) => {
    const id_medicamento = req.params.id_medicamento;
    const nomeMed = req.body.nomeMed;
    const horaTomou = req.body.horaTomou;
    const horaTomara = req.body.horaTomara;
    const fazUso_qtd = req.body.fazUso_qtd;

    const updateQuery = "UPDATE remedio SET nomeMed =?, horaTomou =?, horaTomara =?, fazUso_qtd =? WHERE id_medicamento =?";

    connection.query(updateQuery, [nomeMed, horaTomou, horaTomara, fazUso_qtd, id_medicamento], function (err, result) {
        if (!err) {
            console.log("Dados atualizados.");
            res.send("Dados atualizados.");
        } else {
            console.log("Erro ao atualizar dados", err);
        }
    });
});

/*-------------------Final crud medicamentos-------------------*/


/*Inicio crud contador de remédios*/
app.get("/estoqueremedio", function (req, res) {
    res.sendFile(__dirname + "/estoqueremedio.html")
});

// Endpoint para adicionar medicamentos ao estoque
app.post('/adicionarEstoque', (req, res) => {
    const { nomereme, ultTomado, intervalo, qtdPossui, qtdMin } = req.body;

    const values = [nomereme, ultTomado, intervalo, qtdPossui, qtdMin];
    const insert = "INSERT INTO estoque(nomereme, ultTomado, intervalo, qtdPossui, qtdMin) VALUES (?,?,?,?,?)";

    connection.query(insert, values, function (err, result) {
        if (!err) {
            console.log("Dados inseridos com sucesso!");
            res.send("Dados inseridos!");
        } else {
            console.log("Não foi possível inserir os dados ", err);
            res.send("Erro!");
        }
    });
});

// Rota para listar os dados do BD
app.get("/listarestoque", function (req, res) {
    const selectAll = "SELECT * FROM estoque";

    connection.query(selectAll, function (err, rows) {
        if (!err) {
            res.send(`
                <html lang="pt-br">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Lista de Estoque</title>
                    <link rel="icon" type="image/x-icon" href="icon.png">
                    <link rel="stylesheet" type="text/css" href="/estilo.css">
                    <script src="index.js" defer></script>
                </head>
                <body>
                    <p>Lista de Estoque</p>
                    <div id="page-container">
                        <div id="content-wrap">
                            <table>
                                <tr>
                                    <th>Nome do Medicamento</th>
                                    <th>Ultimo Tomado</th>
                                    <th>A cada ... hs</th>
                                    <th>Possui </th>
                                    <th>Minimo</th>
                                    <th>Editar</th>
                                    <th>Deletar</th>
                                </tr>
                                ${rows.map(row => `
                                <tr>
                                    <td>${row.nomereme}</td>
                                    <td>${row.ultTomado}</td>
                                    <td>${row.intervalo}</td>
                                    <td>${row.qtdPossui}</td>
                                    <td>${row.qtdMin}</td>
                                    <td><a href="/atualizar-estoque-form/${row.id_estoque}">Editar</a></td>
                                    <td><a href="/deletar-estoque/${row.id_estoque}">Deletar</a></td>
                                </tr>
                                `).join('')}
                            </table>
                        </div>
                        <footer>
                            <a href="http://localhost:8081">Voltar</a>
                        </footer>
                    </div>
                </body>
                </html>
            `);
        } else {
            console.log("Erro ao carregar lista do estoque! ", err);
            res.send("Erro!");
        }
    });
});

// Rota para deletar os dados do estoque
app.get("/deletar-estoque/:id_estoque", function (req, res) {
    const id_estoque = req.params.id_estoque;

    const deleteEstoque = "DELETE FROM estoque WHERE id_estoque = ?";

    connection.query(deleteEstoque, [id_estoque], function (err, result) {
        if (!err) {
            console.log("Estoque deletado!");
            res.redirect('/listarestoque');
        } else {
            console.log("Erro ao deletar o estoque!", err);
        }
    });
});

// Rota para atualizar os dados do estoque
app.get("/atualizar-estoque-form/:id_estoque", function (req, res) {
    const id_estoque = req.params.id_estoque;

    const selectestoque = "SELECT * FROM estoque WHERE id_estoque=?";

    connection.query(selectestoque, [id_estoque], function (err, result) {
        if (!err && result.length > 0) {
            const estoque = result[0];

            res.send(`
            <!DOCTYPE html>
            <html lang="pt-br">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Cadastro de Estoque</title>
                <link rel="icon" type="image/x-icon" href="icon.png">
                <link rel="stylesheet" type="text/css" href="/estilo.css">
                <script src="index.js" defer></script>
            </head>
            <body>
                <article>
                    <h1>Cadastro de Estoque</h1>
                    <form class="cadastro" action="/atualizar-estoque/${id_estoque}" method="POST">
                        <div class="field">
                            <label for="nomereme">Nome do Medicamento:</label>
                            <input type="text" id="nomereme" name="nomereme" value="${estoque.nomereme}" required>
                        </div>
                        <div class="field">
                            <label for="ultTomado">Que horas você tomou sua última medicação?(HH:MM):</label>
                            <input type="time" id="ultTomado" name="ultTomado" value="${estoque.ultTomado}" required>
                        </div>
                        <div class="field">
                            <label for="intervalo">Intervalo:</label>
                            <select name="intervalo" id="intervalo" required>
                                <option value="">Selecione</option>
                                <option value="4" ${estoque.intervalo == '4' ? 'selected' : ''}>4hs</option>
                                <option value="6" ${estoque.intervalo == '6' ? 'selected' : ''}>6hs</option>
                                <option value="8" ${estoque.intervalo == '8' ? 'selected' : ''}>8hs</option>
                                <option value="12" ${estoque.intervalo == '12' ? 'selected' : ''}>12h</option>
                            </select>
                        </div>
                        <div class="field">
                            <label for="qtdPossui">Quantidade de medicamento ao todo:</label>
                            <input type="number" id="qtdPossui" name="qtdPossui" value="${estoque.qtdPossui}" required>
                        </div>
                        <div class="field">
                            <label for="qtdMin">Quantidade mínima de medicamento: (Ex: a quantidade mínima será 10, então quando tiver 10 unidades você será informado.)</label>
                            <input type="number" id="qtdMin" name="qtdMin" value="${estoque.qtdMin}" required>
                        </div>
                        <input type="submit" value="Atualizar">
                    </form>
                </article>
                <footer></footer>
            </body>
            </html>
            `);
        } else {
            console.log("Erro ao obter dados do estoque! ", err);
            res.send("Erro!");
        }
    });
});

app.post('/atualizar-estoque/:id_estoque', (req, res) => {
    const id_estoque = req.params.id_estoque;
    const nomereme = req.body.nomereme;
    const ultTomado = req.body.ultTomado;
    const intervalo = req.body.intervalo;
    const qtdPossui = req.body.qtdPossui;
    const qtdMin = req.body.qtdMin;

    const updateQuery = "UPDATE estoque SET nomereme =?, ultTomado =?, intervalo =?, qtdPossui =?, qtdMin =? WHERE id_estoque =?";

    connection.query(updateQuery, [nomereme, ultTomado, intervalo, qtdPossui, qtdMin, id_estoque], function (err, result) {
        if (!err) {
            console.log("Dados atualizados.");
            res.send("Dados atualizados.");
        } else {
            console.log("Erro ao atualizar dados", err);
        }
    });
});


/*-------------------Final curd estoque*-------------------*/





















































/*Inicio crud criar conta*/
app.get("/criarconta", function (req, res) {
    res.sendFile(__dirname + "/criarconta.html")
})

app.post('/adicionarUsuario', (req, res) => {
    const { usuario, senha, email } = req.body;
    const query = 'INSERT INTO criarConta (usuario, senha, email) VALUES (?, ?, ?)';
    connection.query(query, [usuario, senha, email], (err, result) => {
        if (err) {
            console.error('Não foi possível criar a conta!', err);
            res.status(500).send('Erro!');
        } else {
            console.log('Conta criada!');
            res.send('Conta Criada!');
        }
    });
});

// Rota para listar os dados do BD
app.get("/listarusuarios", function (req, res) {
    const selectAll = "SELECT * FROM criarConta";

    connection.query(selectAll, function (err, rows) {
        if (!err) {
            res.send(`
                <html lang="pt-br">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Lista de Usuários</title>
                    <link rel="icon" type="image/x-icon" href="icon.png">
                    <link rel="stylesheet" type="text/css" href="/estilo.css">
                    <script src="index.js" defer></script>
                </head>
                <body>
                    <p>Lista de Usuários</p>
                    <div id="page-container">
                        <div id="content-wrap">
                            <table>
                                <tr>
                                    <th>Usuário</th>
                                    <th>E-mail</th>
                                    <th>Senha</th>
                                    <th>Editar</th>
                                    <th>Deletar</th>
                                </tr>
                                ${rows.map(row => `
                                <tr>
                                    <td>${row.usuario}</td>
                                    <td>${row.email}</td>
                                    <td>${row.senha}</td>
                                    <td><a href="/atualizar-form/${row.id_usuario}">Editar</a></td>
                                    <td><a href="/deletar/${row.id_usuario}">Deletar</a></td>
                                </tr>
                                `).join('')}
                            </table>
                        </div>
                        <footer>
                            <a href="http://localhost:8081">Voltar</a>
                        </footer>
                    </div>
                </body>
                </html>
            `);
        } else {
            console.log("Erro ao carregar lista de usuários! ", err);
            res.send("Erro!");
        }
    });
});

// Rota para deletar os dados
app.get("/deletar/:id_usuario", function (req, res) {
    const id_usuario = req.params.id_usuario;

    const deleteusuario = "DELETE FROM criarConta WHERE id_usuario = ?";

    connection.query(deleteusuario, [id_usuario], function (err, result) {
        if (!err) {
            console.log("Usuário deletado!");
            res.redirect('/listarusuarios');
        } else {
            console.log("Erro ao deletar o usuário!", err);
        }
    });
});

// Rota para atualizar os dados
app.get("/atualizar-form/:id_usuario", function (req, res) {
    const id_usuario = req.params.id_usuario;

    const selectcriarConta = "SELECT * FROM criarConta WHERE id_usuario=?";

    connection.query(selectcriarConta, [id_usuario], function (err, result) {
        if (!err && result.length > 0) {
            const criarConta = result[0];

            res.send(`

            <!DOCTYPE html>
            <html lang="pt-br">
            
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Criar Conta</title>
                <link rel="icon" type="image/x-icon" href="icon.png">
                <link rel="stylesheet" type="text/css" href="/estilo.css">
                <script src="index.js" defer></script>
            </head>
            
            <body>
                <article>
                    <h1>Criar sua Conta</h1>
                    <form class="cadastro" action="/atualizar-form/${id_usuario}" method="POST">
                        <div class="field">
                            <label for="usuario">Crie seu usuário:</label>
                            <input type="text" id="usuario" name="usuario" value="${criarConta.usuario}" required>
                        </div>

                        <div class="field">
                            <label for="email">Crie seu e-mail:</label>
                            <input type="email" id="email" name="email" value="${criarConta.email}" required>
                        </div>
                        <div class="field">
                            <label for="senha">Crie sua senha:</label>
                            <input type="password" id="senha" name="senha" value="${criarConta.senha}" required>
                        </div>          
                        <input type="submit" value="Atualizar">
                    </form>
                </article>
                <footer></footer>
            </body>
            </html>
            `);
        } else {
            console.log("Erro ao obter do usuário! ", err);
            res.send("Erro!")
        }
    })
})

app.post('/atualizar-form/:id_usuario', (req, res) => {
    const id_usuario = req.params.id_usuario;
    const usuario = req.body.usuario;
    const email = req.body.email
    const senha = req.body.senha;
    


    const updateQuery = "UPDATE criarConta SET usuario =?, email =?, senha =?  WHERE id_usuario =?";

    connection.query(updateQuery, [usuario, email, senha, id_usuario], function (err, result) {
        if (!err) {
            console.log("Dados atualizados.")
            res.send("Dados atualizados.")
        } else {
            console.log("Erro ao atualizar dados", err);
        }
    });
});

app.listen(8081, function () {
    console.log("Servidor rodando na url http://localhost:8081");
});
